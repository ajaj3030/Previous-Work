#include "EnergyCounter.h"
//#include "PositionFinder.h"
#include "g4csv.hh"
#include "G4RunManager.hh"

EnergyCounter::EnergyCounter( const G4String& name, const G4int id)
  : G4VSensitiveDetector( name ) // Run the constructor of the parent class
{
  // Set which histogram ID / ntuple column to use
  m_ID = id;
  Name = name;
  //Hist_ID = hist;
}

EnergyCounter::~EnergyCounter()
{
}

// At the start of the event, zero the energy counter
void EnergyCounter::Initialize( G4HCofThisEvent* )
{
  m_totalEnergy = 0.0;
}

// Analyse anything that hits the detector
G4bool EnergyCounter::ProcessHits( G4Step* step, G4TouchableHistory* )
{
  // Get the energy deposited by this hit
  G4double edep = step->GetTotalEnergyDeposit();

  // Add to the total energy in this object
  m_totalEnergy += edep;

  return true;
}

// At the end of an event, store the energy collected in this detector
void EnergyCounter::EndOfEvent( G4HCofThisEvent* )
{
  // Display the total
  G4cout << this->GetName() << " total energy = " << m_totalEnergy << G4endl;

  // Get the analysis manager
  auto analysisManager = G4AnalysisManager::Instance();


  // Fill histogram (histogram 0, bin by layer ID)
  analysisManager->FillH1( 0, m_ID, m_totalEnergy );

   //Fill ntuple (ntuple 0, column by layer ID)
  analysisManager->FillNtupleDColumn( 0, m_ID, m_totalEnergy );

// if (m_ID >=6){
  // Fill histogram (histogram 0, bin by layer ID)
  //analysisManager->FillH1( 1, m_ID-6, m_totalEnergy );

 //Fill ntuple (ntuple 0, column by layer ID)
 //analysisManager->FillNtupleDColumn( 1, m_ID-6, m_totalEnergy );
//}


}

PositionFinder::PositionFinder( const G4String& name, const G4int id)
  : G4VSensitiveDetector( name ) // Run the constructor of the parent class
{
  // Set which histogram ID / ntuple column to use
  hid = id;
  //Name = name;
  //Hist_ID = hist;
}

PositionFinder::~PositionFinder()
{
}

void PositionFinder::Initialize( G4HCofThisEvent* )
{
}

// Analyse anything that hit the detector
G4bool PositionFinder::ProcessHits( G4Step* step, G4TouchableHistory* )
{
  // Tracking detectors only sense charged particles
  if ( step->GetTrack()->GetParticleDefinition()->GetPDGCharge() != 0.0 )
  {
    // Get the analysis manager
    auto analysisManager = G4AnalysisManager::Instance();

    //I HAD TO EDIT THE ENERGY COUNTER FILE TO ALSO WRITE OUT DATA FOR THE SILICON TRACKERS IN DIFFERENT FILES. PROVED UNEXPECTEDLY DIFFICULT TRYING TO GET THIS AND THE INCLUDE FILE TO WORK.

    // Fill ntuple with my ID number
    G4Track* track = step-> GetTrack();

    G4String part = track->GetParticleDefinition()->GetParticleName();
    analysisManager->FillNtupleSColumn( hid, 0, part);
    analysisManager->FillNtupleDColumn( hid, 1, G4RunManager::GetRunManager()->GetCurrentEvent()->GetEventID() ); // Column 0 - event number
    analysisManager->FillNtupleDColumn( hid, 2, step->GetTrack()->GetPosition().phi() );                          // Column 1 - phi coordinate of hit
    analysisManager->FillNtupleDColumn( hid, 3, step->GetTrack()->GetPosition().theta() );                        // Column 2 - theta coordinate of hit
    analysisManager->AddNtupleRow( hid ); // Row complete
  }

  return true;
}

void PositionFinder::EndOfEvent( G4HCofThisEvent* )
{
}
