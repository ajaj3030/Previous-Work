#include "GeneratorAction.h"
#include <iostream>
#include <cstdlib>
#include <ctime>
#include "G4ParticleTable.hh"
#include "G4SystemOfUnits.hh"
#include "g4csv.hh"

GeneratorAction::GeneratorAction() : G4VUserPrimaryGeneratorAction()
{
  G4int nofParticles = 1;
  m_particleGun = new G4ParticleGun( nofParticles );

  // Default particle
  G4ParticleDefinition * particleDefinition = G4ParticleTable::GetParticleTable()->FindParticle( "e-" );
  m_particleGun->SetParticleDefinition( particleDefinition );
  m_particleGun->SetParticlePosition( G4ThreeVector( 0.0, 0.0, -150.0*cm ) ); // I moved the gun closer to the detector so it didnt fly away due to the B field
  m_particleGun->SetParticleMomentumDirection( G4ThreeVector( 0.0, 0.0, 1.0 ) ); // along z axis
  m_particleGun->SetParticleEnergy( 300.0*MeV );
}

GeneratorAction::~GeneratorAction()
{
  delete m_particleGun;
}

// This function is called at the begining of event
void GeneratorAction::GeneratePrimaries( G4Event* anEvent )
{
  // Fire a particle
  m_particleGun->GeneratePrimaryVertex( anEvent );

  // Store truth information - first column
  auto analysisManager = G4AnalysisManager::Instance();
  G4double particleEnergy = m_particleGun->GetParticleEnergy();
  analysisManager->FillNtupleDColumn( 0, 0, particleEnergy );

  // This lets me test a range of energies over a couple orders of magnetitudes
  particleEnergy = particleEnergy + 100;

  ////////////More Improvement Section, I do take it to less than 2 orders of magnitude here - EXCLUSIVELY FOR THE BIG NN DATASET, I GO BACK TO 2 ORDERS AFTER- for timekeeping purposes ///////////////////////

  //Below condition also used to keep NN data generation a bit faster
  //if (particleEnergy >=50000* MeV)
  //{
    //particleEnergy = 1000* MeV;
//  }

  m_particleGun->SetParticleEnergy(particleEnergy*MeV);


  //I use random numbers to randomly assign a particle at each iteration

  srand(time(NULL));
  double rand_num = (double) rand() / RAND_MAX;

  if (rand_num > 0.9)
  {
    G4ParticleDefinition * particleDefinition1 = G4ParticleTable::GetParticleTable()->FindParticle( "e-" );
    m_particleGun->SetParticleDefinition( particleDefinition1 );
  }

  else if (rand_num >=0 && rand_num <0.1)
  {
    G4ParticleDefinition * particleDefinition2 = G4ParticleTable::GetParticleTable()->FindParticle( "e+" );
    m_particleGun->SetParticleDefinition( particleDefinition2 );
  }

////////////////////////////BELOW ADDED IN "Improvement" Section////////////////////////////////////////////////////////////////

  else if (rand_num >0.2 && rand_num <0.3)
  {
     G4ParticleDefinition * particleDefinition3 = G4ParticleTable::GetParticleTable()->FindParticle( "kaon+" );
    m_particleGun->SetParticleDefinition( particleDefinition3 );
  }

  else if (rand_num >0.3 && rand_num <0.4)
  {
    G4ParticleDefinition * particleDefinition4 = G4ParticleTable::GetParticleTable()->FindParticle( "kaon-" );
    m_particleGun->SetParticleDefinition( particleDefinition4 );
  }


///////////////////Adding even MORE partciles to really stress test the NN ///////////////////////////////////////////////////////////

else if (rand_num >=0.3 && rand_num <0.4)
{
   G4ParticleDefinition * particleDefinition5 = G4ParticleTable::GetParticleTable()->FindParticle( "pi+" );
  m_particleGun->SetParticleDefinition( particleDefinition5 );
}

else if (rand_num >=0.5 && rand_num <0.6)
{
   G4ParticleDefinition * particleDefinition6 = G4ParticleTable::GetParticleTable()->FindParticle( "pi-" );
  m_particleGun->SetParticleDefinition( particleDefinition6 );
}

else if (rand_num >=0.6 && rand_num <0.7)
{
   G4ParticleDefinition * particleDefinition7 = G4ParticleTable::GetParticleTable()->FindParticle( "neutron" );
  m_particleGun->SetParticleDefinition( particleDefinition7 );
}

else if (rand_num >=0.7 && rand_num <0.8)
{
   G4ParticleDefinition * particleDefinition8 = G4ParticleTable::GetParticleTable()->FindParticle( "gamma" );
  m_particleGun->SetParticleDefinition( particleDefinition8 );
}


else if (rand_num >=0.8 && rand_num <0.9)
{
   G4ParticleDefinition * particleDefinition9= G4ParticleTable::GetParticleTable()->FindParticle( "kaon+" );
  m_particleGun->SetParticleDefinition( particleDefinition9 );
}


}
